const express= require('express')
const app=express()
const mongoose= require('mongoose')
app.use(express.urlencoded({extended:false}))
const adminRouter= require('./routers/admin')
const userRouter= require('./routers/user')
const session= require('express-session')

mongoose.connect('mongodb://127.0.0.1:27017/thirdnode', ()=>{console.log('connected to thirdnode db')})

 
app.use(session({
secret:'harsh',
resave:false,
saveUninitialized:false
  
}))
app.set('view engine', 'ejs')
app.use(userRouter)
app.use('/admin',adminRouter)
app.use(express.static('public'))
app.listen(5000, ()=>{console.log('server is running on port 5000')})


















