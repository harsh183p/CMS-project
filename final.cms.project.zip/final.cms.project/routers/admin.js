const router= require('express').Router()
const adminregc=require('../controllers/adminregcontroller')
const bannerc=require('../controllers/bannercontroller')
const testic= require('../controllers/testicontroller')
const servicesc= require('../controllers/servicescontroller')
const queryc=require('../controllers/querycontroller')
const contactc= require('../controllers/contactcontroller')
const parkingc= require('../controllers/parkingcontroller')
const multer= require('multer')




let storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/upload')
    },
    filename:function(req,file,cb){
        cb(null,Date.now()+file.originalname)
    }
})

let upload= multer({
    storage:storage,
    limits:{fileSize:1024*1024*4}
})

function handllogin(req,res,next){
    if(req.session.isAuth){
        next()
    }else{
        res.redirect('/admin/')
    }
}


router.get("/",(req,res)=>{

    res.render('admin/adminlogin.ejs')
})

router.post('/login',adminregc.adminlog)
router.get('/dashboard', handllogin,adminregc.showdashboard)
router.get('/logout',adminregc.adminlogout)
router.get('/banner',bannerc.adminbannershow)
router.get('/bannerupdate/:id',bannerc.adminbannerupdate)
router.post('/bannerupdaterecord/:id',upload.single('img'),bannerc.adminbannerupdaterecord)
router.get('/services',servicesc.adminservicepagedisplay)
router.get('/serviceadd',servicesc.adminserviceaddform)
router.post('/servicerecord',upload.single('img'),servicesc.adminserviceadd)
router.get('/servicedelete/:id',servicesc.adminserverdelete)
router.get('/serverstatusupdate/:id',servicesc.adminserviceupdate)
router.get('/query',queryc.adminshow)
router.get('/queryform/:id',queryc.adminqueryformshow)
router.post('/queryformreply/:id',upload.single('attachement'),queryc.adminquerysend)
router.get('/querydelete/:id',queryc.adminquerydelete)
router.get('/contact',contactc.showcontact)
router.get('/contactupdate/:id',contactc.showupdatepage)
router.post('/contactrecords/:id',contactc.contactupdate)
// router.get('/testi',testic.adminshow)
router.get('/parking',parkingc.parkingshow)
router.get('/parkingform',parkingc.parkingfrom)
router.post('/parkingrecord',parkingc.parkingrecord)
//router.get('/out/:id',parkingc.outform)
router.get('/outrecord/:id',parkingc.outrecords)
router.get('/printout/:id',parkingc.printout)
router.get('/testis',testic.admintestipagedisplay)
router.get('/testiadd',testic.admintestiaddform)
router.post('/testirecord',testic.admintestiadd)
router.get('/testidelete/:id',testic.admintestidelete)
router.get('/testistatusupdate/:id',testic.admintestiupdate)




module.exports=router