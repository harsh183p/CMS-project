const router= require('express').Router()
const Banner= require('../models/banner')
const testi=require('../models/testi')
const service= require('../models/server')
const Query= require('../models/query')
const bannerc=require('../controllers/bannercontroller')
const testic= require('../controllers/testicontroller')
const servicesc= require('../controllers/servicescontroller')
const queryc=require('../controllers/querycontroller')
const contactc= require('../controllers/contactcontroller')
const contact=require('../models/contact')


router.get("/",async(req,res)=>{
    const bannerrecord= await Banner.findOne()
       const serverrecord =await service.find({status:'publish'})
const contactrecord=await contact.findOne()
      // console.log(serverrecord)
res.render('index.ejs',{bannerrecord,serverrecord,contactrecord})
})



router.post('/queryrecords',async(req,res)=>{
const {email,query} =req.body
const record = new Query({email:email,query:query})
await record.save()
res.redirect('/')
// console.log(record)

})
router.get('/banner',bannerc.bannersingle)
router.get('/servicedetail/:id',servicesc.servicessingledetail)




module.exports=router
