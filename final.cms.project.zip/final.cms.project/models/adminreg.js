const mongoose=require('mongoose')


const adminreg=mongoose.Schema({

  username: String,
  password: String

})
module.exports = mongoose.model('adminreg',adminreg)