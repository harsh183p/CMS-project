const mongoose= require('mongoose')


const serverSchema= mongoose.Schema({
img:String,
name:String,
desc:String,
ldesc:String,
status:{type:String,default:'unpublic'},
postedDate:Date
})




module.exports= mongoose.model('service',serverSchema)