const mongoose= require('mongoose')


const parkingShema= mongoose.Schema({

vnumber:String,
vtype:String,
vintime:Date,
vouttime:Date,
vstatus:{type:String,default:'IN'},
amount:Number


})




module.exports =mongoose.model('parking',parkingShema)