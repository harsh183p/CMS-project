const mongoose= require('mongoose')



const testiSchema= mongoose.Schema({
 img:String,
 name:String,
 quote:String,
cname:String,
status:{type:String,default:'unpublic'},
postedDate:Date
})

 
module.exports= mongoose.model('testi',testiSchema)