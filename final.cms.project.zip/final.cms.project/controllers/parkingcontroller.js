const Parking =require('../models/parking')


exports.parkingshow=async(req,res)=>{
    const record=await Parking.find()
    res.render('admin/parking.ejs',{record})
}

exports.parkingfrom=(req,res)=>{
    res.render('admin/parkingform.ejs')
}

exports.parkingrecord=async(req,res)=>{
    const{vnumber,vtype}=req.body
const record=new Parking({vnumber:vnumber,vtype:vtype,vintime:new Date()})
await record.save()
console.log(record)
}

exports.outform=(req,res)=>{
    const id=req.params.id
    res.render('admin/outform.ejs',{id})
}

exports.outrecords=async(req,res)=>{
    const id=req.params.id
    //const {outtime}=req.body
     let outtime=new Date()
const record=await Parking.findById(id)
 const totalhours=(outtime-record.vintime)/(1000*60*60)
 console.log(totalhours)
 let amount=0
 if(record.vtype=='2w'){
    amount=Math.round(totalhours*30)
 }else if(record.vtype=='3w'){
    amount=Math.round(totalhours*50)
 }
 else if(record.vtype=='4w'){
    amount=Math.round(totalhours*80)
 }
 else if(record.vtype=='lw'){
    amount=Math.round(totalhours*120)
 }else{
    amount=Math.round(totalhours*140)
 }
 await Parking.findByIdAndUpdate(id,{vouttime:outtime,amount:amount,vstatus:'OUT'})
 res.redirect('/admin/parking')
}
exports.printout=async(req,res)=>{
    const id=req.params.id
    const record=await Parking.findById(id)
    res.render('admin/printout.ejs',{record})
}