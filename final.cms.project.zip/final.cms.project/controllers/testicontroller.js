const Testi= require('../models/testi')
const contact=require('../models/contact')

exports.admintestipagedisplay=async(req,res)=>{
    const record = await Testi.find().sort({postedDate:-1})
    const testiscount = await    Testi.count()
    const unpublishcount = await Testi.count({status:'unpublic'})
    const publishcount = await   Testi.count({status:'publish'})
     res.render('admin/testi.ejs',{record,testiscount,unpublishcount,publishcount})
}

exports.admintestiaddform=(req,res)=>{
    res.render('admin/testiform.ejs')
}

exports.admintestiadd=async(req,res)=>{
    const {timg,tquote,tcname}=req.body
    const currentdate= new Date()
    const record=new Testi({img:timg,name:tcname,quote:tquote,postedDate:currentdate})
    await record.save()

    console.log(record)
res.redirect('/admin/testis')
}

exports.admintestidelete=async(req,res)=>{
    const id= req.params.id
    await Testi.findByIdAndDelete(id)
    res.redirect('/admin/testis')
    }


    exports.admintestiupdate=async(req,res)=>{
        const id= req.params.id
        const record= await Testi.findById(id)
    let status=null
    if(record.status=='unpublic'){
        status='publish'
        }else{
            status='unpublic'
        }
        await Testi.findByIdAndUpdate(id,{status:status})
        res.redirect('/admin/testis')
    }

    exports.testisingledetail=async(req,res)=>{
        const id =req.params.id
        const record= await Testi.findById(id)
        const contactrecord=await contact.findOne()
        res.render('testi.ejs',{record,contactrecord})
    
    
    }
