const Services= require('../models/server')
const contact=require('../models/contact')

exports.adminservicepagedisplay=async(req,res)=>{
const record = await Services.find().sort({postedDate:-1})
const servicescount = await Services.count()
const unpublishcount = await Services.count({status:'unpublic'})
const publishcount = await Services.count({status:'publish'})
    res.render('admin/service.ejs',{record,servicescount,publishcount,unpublishcount})    


}

exports.adminserviceaddform=(req,res)=>{
    res.render('admin/serviceform.ejs')

}

exports.adminserviceadd=async(req,res)=>{
   const filename= req.file.filename
   const currentdate= new Date()
 const {sname,sdesc,sldesc}=req.body
const record= new Services({name:sname,desc:sdesc,ldesc:sldesc,img:filename,postedDate:currentdate})
await record.save()
//console.log(record)
res.redirect('/admin/services')

}
exports.adminserverdelete=async(req,res)=>{
const id= req.params.id
await Services.findByIdAndDelete(id)
res.redirect('/admin/services')
}

exports.adminserviceupdate=async(req,res)=>{
    const id= req.params.id
    const record= await Services.findById(id)
let status=null
if(record.status=='unpublic'){
    status='publish'
    }else{
        status='unpublic'
    }
    await Services.findByIdAndUpdate(id,{status:status})
    res.redirect('/admin/services')
}

exports.servicessingledetail=async(req,res)=>{
    const id =req.params.id
    const record= await Services.findById(id)
    const contactrecord=await contact.findOne()
    res.render('service.ejs',{record,contactrecord})


}