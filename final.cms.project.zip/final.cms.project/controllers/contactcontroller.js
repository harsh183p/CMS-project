const contact= require('../models/contact')



exports.showcontact=async(req,res)=>{
   const record= await contact.findOne()
    res.render('admin/contact.ejs',{record})
}
exports.showupdatepage=async(req,res)=>{
    const id=req.params.id
    const record=await contact.findById(id)
    res.render('admin/contactform.ejs',{record})
}

exports.contactupdate=async(req,res)=>{
    const id=req.params.id
    const {add,linkedin,snap,twitter}=req.body
    await contact.findByIdAndUpdate(id,{address:add,linkedin:linkedin,snap:snap,twitter:twitter})
    res.redirect('/admin/contact')
}


