const Query= require('../models/query')
const nodemailer=require('nodemailer')


exports.adminshow=async(req,res)=>{
    const record = await Query.find()
     res.render('admin/query.ejs',{record})
 }
 


exports.adminqueryformshow=async(req,res)=>{
    const id=req.params.id
    const record=await Query.findById(id)
    res.render('admin/queryform.ejs',{record})
}

exports.adminquerysend=async(req,res)=>{
const id=req.params.id
const filepath=req.file.path
const{emailto,emailfrom,emailsub,emailbody}=req.body



let testAccount = await nodemailer.createTestAccount();

// create reusable transporter object using the default SMTP transport
let transporter = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 587,
  secure: false, // true for 465, false for other ports
  auth: {
    user:'harsh183p@gmail.com', // generated ethereal user
    pass:'rplthuxcjvesmkkb', // generated ethereal password
  },
});

 // send mail with defined transport object
 let info = await transporter.sendMail({
  from:emailfrom, // sender address
  to:emailto, // list of receivers
  subject:emailsub, // Subject line
  text:emailbody, // plain text body
  //html: "<b>Hello world?</b>", // html body

  attachments:[
    {path:filepath}
  ]
});

await Query.findByIdAndUpdate(id,{status:'read'})
res.redirect('/admin/query')

// res.render('/admin/queryreply.ejs')

}

exports.adminquerydelete=async(req,res)=>{
  const id= req.params.id
  await Query.findByIdAndDelete(id)
  res.redirect('/admin/query')
}