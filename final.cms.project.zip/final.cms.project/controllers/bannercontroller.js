const Banner=require('../models/banner')
const contact=require('../models/contact')

exports.adminbannershow=async(req,res)=>{
const record= await Banner.findOne()
///console.log(record)
res.render('admin/banner.ejs',{record})
}

exports.adminbannerupdate=async(req,res)=>{
  
    const id=req.params.id
   const record= await Banner.findById(id)
///console.log(record)
    res.render('admin/bannerupdate.ejs',{record})
}

exports.adminbannerupdaterecord=async(req,res)=>{
    const {bt,bd,bdl} = req.body
    const id= req.params.id
    const filename=req.file.filename
if(req.file){
       await Banner.findByIdAndUpdate(id,{title:bt,desc:bd,ldesc:bdl,img:filename})}
    else{await Banner.findByIdAndUpdate(id,{title:bt,desc:bd,ldesc:bdl,img:filename})}
   res.redirect('/admin/banner')
}


exports.bannersingle=async(req,res)=>{
    const record= await Banner.findOne()
    const contactrecord=await contact.findOne()
res.render('banner.ejs',{record,contactrecord})
}